/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package controllers;

import models.Kendaraan;

public interface CRUDKendaraan {
    void tambahKendaraan(Kendaraan kendaraan);
    void lihatKendaraan();
    void updateKendaraan(int index, Kendaraan kendaraanBaru);
    void hapusKendaraan(int index);
}