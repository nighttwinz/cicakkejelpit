/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllers;

import models.Kendaraan;
import java.util.ArrayList;

public class PengelolaKendaraan implements CRUDKendaraan {
    private final ArrayList<Kendaraan> daftarKendaraan = new ArrayList<>();

    @Override
    public void tambahKendaraan(Kendaraan kendaraan) {
        daftarKendaraan.add(kendaraan);
        System.out.println("Kendaraan berhasil ditambahkan.");
    }

    @Override
    public void lihatKendaraan() {
        if (daftarKendaraan.isEmpty()) {
            System.out.println("Tidak ada kendaraan yang terdaftar.");
        } else {
            for (Kendaraan kendaraan : daftarKendaraan) {
                kendaraan.tampilkanInfo();
                System.out.println("-----------------------");
            }
        }
    }

    @Override
    public void updateKendaraan(int index, Kendaraan kendaraanBaru) {
        if (index >= 0 && index < daftarKendaraan.size()) {
            daftarKendaraan.set(index, kendaraanBaru);
            System.out.println("Kendaraan berhasil diperbarui.");
        } else {
            System.out.println("Indeks tidak valid.");
        }
    }

    @Override
    public void hapusKendaraan(int index) {
        if (index >= 0 && index < daftarKendaraan.size()) {
            daftarKendaraan.remove(index);
            System.out.println("Kendaraan berhasil dihapus.");
        } else {
            System.out.println("Indeks tidak valid.");
        }
    }
}
