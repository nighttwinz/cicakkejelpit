/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import controllers.PengelolaKendaraan;
import models.Mobil;
import models.Motor;
import models.Kendaraan;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            PengelolaKendaraan pengelola = new PengelolaKendaraan();
            int pilihan;
            
            do {
                System.out.println("=== Menu Manajemen Kendaraan ===");
                System.out.println("1. Tambah Mobil");
                System.out.println("2. Tambah Motor");
                System.out.println("3. Lihat Semua Kendaraan");
                System.out.println("4. Update Kendaraan");
                System.out.println("5. Hapus Kendaraan");
                System.out.println("6. Keluar");
                System.out.print("Masukkan pilihan: ");
                pilihan = scanner.nextInt();
                scanner.nextLine();  // Konsumsi karakter newline
                
                switch (pilihan) {
                    case 1 -> {
                        System.out.print("Masukkan nomor plat: ");
                        String platMobil = scanner.nextLine();
                        System.out.print("Masukkan merk: ");
                        String merkMobil = scanner.nextLine();
                        System.out.print("Masukkan tahun: ");
                        int tahunMobil = scanner.nextInt();
                        scanner.nextLine();  // Konsumsi newline
                        System.out.print("Masukkan tipe mesin: ");
                        String tipeMesin = scanner.nextLine();
                        Kendaraan mobil = new Mobil(platMobil, merkMobil, tahunMobil, tipeMesin);
                        pengelola.tambahKendaraan(mobil);
                    }
                        
                    case 2 -> {
                        System.out.print("Masukkan nomor plat: ");
                        String platMotor = scanner.nextLine();
                        System.out.print("Masukkan merk: ");
                        String merkMotor = scanner.nextLine();
                        System.out.print("Masukkan tahun: ");
                        int tahunMotor = scanner.nextInt();
                        scanner.nextLine();  // Konsumsi newline
                        System.out.print("Masukkan jenis motor: ");
                        String jenisMotor = scanner.nextLine();
                        Kendaraan motor = new Motor(platMotor, merkMotor, tahunMotor, jenisMotor);
                        pengelola.tambahKendaraan(motor);
                    }
                        
                    case 3 -> pengelola.lihatKendaraan();
                        
                    case 4 -> {
                        System.out.print("Masukkan indeks kendaraan yang ingin diupdate: ");
                        int indexUpdate = scanner.nextInt();
                        scanner.nextLine();  // Konsumsi newline
                        System.out.print("Masukkan nomor plat baru: ");
                        String platBaru = scanner.nextLine();
                        System.out.print("Masukkan merk baru: ");
                        String merkBaru = scanner.nextLine();
                        System.out.print("Masukkan tahun baru: ");
                        int tahunBaru = scanner.nextInt();
                        scanner.nextLine();  // Konsumsi newline
                        System.out.print("Masukkan tipe baru (untuk mobil) atau jenis baru (untuk motor): ");
                        String tipeBaru = scanner.nextLine();
                        Kendaraan kendaraanBaru = new Mobil(platBaru, merkBaru, tahunBaru, tipeBaru); // contoh untuk Mobil
                        pengelola.updateKendaraan(indexUpdate, kendaraanBaru);
                    }
                        
                    case 5 -> {
                        System.out.print("Masukkan indeks kendaraan yang ingin dihapus: ");
                        int indexHapus = scanner.nextInt();
                        pengelola.hapusKendaraan(indexHapus);
                    }
                        
                    case 6 -> System.out.println("Keluar dari program...");
                        
                    default -> System.out.println("Pilihan tidak valid!");
                }
                
            } while (pilihan != 6);
        }
    }
}
