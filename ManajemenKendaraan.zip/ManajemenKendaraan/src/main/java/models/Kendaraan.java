/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

public abstract class Kendaraan {
    private final String nomorPlat;
    private final String merk;
    private final int tahun;

    public Kendaraan(String nomorPlat, String merk, int tahun) {
        this.nomorPlat = nomorPlat;
        this.merk = merk;
        this.tahun = tahun;
    }

    public String getNomorPlat() {
        return nomorPlat;
    }

    public String getMerk() {
        return merk;
    }

    public int getTahun() {
        return tahun;
    }

    public abstract void tampilkanInfo();
}

