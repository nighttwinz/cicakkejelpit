/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

public class Mobil extends Kendaraan {
    private String tipeMesin;

    public Mobil(String nomorPlat, String merk, int tahun, String tipeMesin) {
        super(nomorPlat, merk, tahun);
        this.tipeMesin = tipeMesin;
    }

    public String getTipeMesin() {
        return tipeMesin;
    }

    public void setTipeMesin(String tipeMesin) {
        this.tipeMesin = tipeMesin;
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Mobil: " + getNomorPlat() + ", " + getMerk() + ", Tahun: " + getTahun() + ", Tipe Mesin: " + tipeMesin);
    }
}
