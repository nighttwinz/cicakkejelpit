/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

public class Motor extends Kendaraan {
    private String jenisMotor;

    public Motor(String nomorPlat, String merk, int tahun, String jenisMotor) {
        super(nomorPlat, merk, tahun);
        this.jenisMotor = jenisMotor;
    }

    public String getJenisMotor() {
        return jenisMotor;
    }

    public void setJenisMotor(String jenisMotor) {
        this.jenisMotor = jenisMotor;
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("Motor: " + getNomorPlat() + ", " + getMerk() + ", Tahun: " + getTahun() + ", Jenis: " + jenisMotor);
    }
}
